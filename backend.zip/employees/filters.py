import django_filters
from .models import Employee, EmployeeFieldValue
from fields.models import FieldDefinition
import datetime

class EmployeeFilter(django_filters.FilterSet):
    direction = django_filters.NumberFilter(field_name='direction__id')
    manager   = django_filters.NumberFilter(field_name='manager__id')
    tags      = django_filters.ModelMultipleChoiceFilter(
        field_name='tags__id',
        to_field_name='id',
        queryset=Employee._meta.get_field('tags').related_model.objects.all()
    )
    expiry_in = django_filters.NumberFilter(method='filter_expiry')

    # Фильтры для динамических полей (например, свободных полей)
    dynamic_field = django_filters.CharFilter(method='filter_dynamic_fields')

    class Meta:
        model = Employee
        fields = ['direction', 'manager', 'tags', 'expiry_in', 'dynamic_field']

    def filter_expiry(self, queryset, name, value):
        # Фильтрация по истекающим документам
        expiry_defs = FieldDefinition.objects.filter(field_type='date')
        threshold = django_filters.utils.iso8601.parse_date(
            (django_filters.utils.now().date() + datetime.timedelta(days=value)).isoformat()
        )
        return queryset.filter(
            field_values__definition__in=expiry_defs,
            field_values__value_date__lte=threshold
        ).distinct()

    def filter_dynamic_fields(self, queryset, name, value):
        # Фильтрация по динамическим полям (например, свободным полям)
        dynamic_field = FieldDefinition.objects.filter(label=value).first()
        if dynamic_field:
            return queryset.filter(field_values__field_definition=dynamic_field)
        return queryset
