from rest_framework import serializers
from .models import Direction, Employee, EmployeeFieldValue
from tags.models import Tag

class DirectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Direction
        fields = ['id', 'name']

class EmployeeFieldValueSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeFieldValue
        fields = ['employee', 'field_definition', 'value_text', 'value_date']

class EmployeeSerializer(serializers.ModelSerializer):
    direction_id = serializers.PrimaryKeyRelatedField(
        queryset=Direction.objects.all(),
        write_only=True,
        source='direction'
    )
    direction = serializers.PrimaryKeyRelatedField(
        read_only=True, source='direction'
    )
    tags = serializers.PrimaryKeyRelatedField(
        queryset=Tag.objects.all(), many=True
    )

    field_values = EmployeeFieldValueSerializer(many=True, read_only=True)

    class Meta:
        model = Employee
        fields = (
            'id',
            'first_name', 'last_name', 'full_name',
            'direction', 'direction_id',
            'position', 'manager', 'hired_at',
            'tags', 'field_values'
        )
