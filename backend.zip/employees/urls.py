from django.urls import include, path
from rest_framework.routers import DefaultRouter
from .views import EmployeeViewSet, DirectionViewSet

router = DefaultRouter()
router.register(r'employees', EmployeeViewSet, basename='employee')
router.register(r'directions', DirectionViewSet, basename='direction')

urlpatterns = router.urls
