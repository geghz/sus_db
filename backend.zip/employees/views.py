from rest_framework import viewsets, permissions, filters
from django_filters.rest_framework import DjangoFilterBackend
from .models import Employee, Direction
from .serializers import EmployeeSerializer, DirectionSerializer
from .filters import EmployeeFilter

class DirectionViewSet(viewsets.ModelViewSet):
    queryset = Direction.objects.all()
    serializer_class = DirectionSerializer 

class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [
        DjangoFilterBackend,
        filters.SearchFilter,
        filters.OrderingFilter
    ]
    filterset_class = EmployeeFilter
    search_fields = ['first_name', 'last_name', 'user__email']
    ordering_fields = ['last_name', 'first_name', 'direction__name']

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user

        # Фильтрация по роли пользователя
        if user.is_staff:
            # Для админа — показываем все данные
            return qs
        elif hasattr(user, 'role'):
            if user.role == 'manager':
                # Менеджер видит только сотрудников в своём направлении и своей должности
                return qs.filter(direction__id=user.manager.direction.id, position=user.position)
            elif user.role == 'employee':
                # Обычный сотрудник видит только свои данные
                return qs.filter(user=user)
        return qs
