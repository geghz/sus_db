from django.db import models
from employees.models import Employee

FIELD_TYPES = [
    ('text','Текст'),
    ('date','Дата'),
    ('file','Файл'),
]

class FieldGroup(models.Model):
    name = models.CharField("Группа полей", max_length=100)
    code = models.CharField(max_length=100, unique=True, blank=True, null=True)

    @property
    def has_expiry(self) -> bool:
        return self.definitions.filter(field_type='date').exists()

    def __str__(self):
        return self.name

class FieldDefinition(models.Model):
    group = models.ForeignKey(FieldGroup, on_delete=models.CASCADE, related_name='definitions')
    name = models.CharField("Название поля", max_length=100)
    field_type = models.CharField("Тип", max_length=10, choices=FIELD_TYPES)
    required = models.BooleanField("Обязательное", default=False)

    def __str__(self):
        return f"{self.group.name} / {self.name}"

class FieldDefinitionValue(models.Model):
    employee = models.ForeignKey(
        Employee, related_name='field_values_in_fields', on_delete=models.CASCADE
    )
    field_definition = models.ForeignKey(
        FieldDefinition, related_name='field_values', on_delete=models.CASCADE
    )
    value_text = models.TextField(null=True, blank=True)
    value_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"Field Value for {self.employee.full_name}"
